var class_graph =
[
    [ "bellman_ford", "class_graph.html#ab41fcfa636a1844328496e7f14c3e732", null ],
    [ "bellman_ford_thread_pool", "class_graph.html#a10b47d417fdb4c6d940a6e4d7e3e47c3", null ],
    [ "bfs", "class_graph.html#ac33dfe3921a186aa5d9ebb97b3c831c9", null ],
    [ "bfs_parallel", "class_graph.html#a233db515f2996bca3d2475bd1b5d5b46", null ],
    [ "floyd_warshall", "class_graph.html#a018db74c23245327c519109dec8d5681", null ],
    [ "floyd_warshall_thread_pool", "class_graph.html#aaa6b0c3c8cca3eec4f1be97dfa9a2a65", null ],
    [ "PageRank", "class_graph.html#a25179f6d9c3db4b29d65310d3153cf0a", null ],
    [ "PageRank_thread_pool", "class_graph.html#ab2de8fd75742e225778f4c1d8fc48d0a", null ]
];